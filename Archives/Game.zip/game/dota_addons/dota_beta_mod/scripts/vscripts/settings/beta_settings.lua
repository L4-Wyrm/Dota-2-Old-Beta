--//////////////////////////////////////////////////////////////
-- This file is created for custom gamemode: Dota 2 Old Beta. //
-- 			DO NOT CHANGE ANYTING THERE!	      			  //
--//////////////////////////////////////////////////////////////

-- In this file you can set up the settings for this game mode.

-- Sets gold for those players who random the hero (Meaning they random hero theyself's by pressing the button, not when game select random hero for players)
RANDOMED_GOLD = 852

-- Bots difficulty. (passive,easy,normal,hard,unfair) Default: hard
BOTS_DIFFICULTY = "hard"

-- Enable bots in developer workshop tools mode? Default: false
TOOLSBOTS = false

-- Enable bots with cheats enabled? Default: false
CHEATSBOTS = false